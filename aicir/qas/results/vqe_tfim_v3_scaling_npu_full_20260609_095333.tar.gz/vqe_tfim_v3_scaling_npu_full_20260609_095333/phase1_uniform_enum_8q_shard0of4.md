VQE-QAS full enumeration baseline: tfim_chain_8q_J1_h0.5
reference_energy: -7.640593
n_candidates: 27
hamiltonian_profile: ZZ=0.636, XX=0.000, singleX=0.364

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -7.635495 | 0.005098 | 32 | 915 | ry_cx_linear_L3 | hea_mask_L3_ry_cx_linear_ry
2 | -7.634951 | 0.005641 | 24 | 1135 | ry_cz_linear_L2 | hea_mask_L2_ry_cz_linear_ry
3 | -7.634768 | 0.005824 | 56 | 2761 | rx_ry_rz_cz_linear_L2 | hea_mask_L2_rx_ry_rz_cz_linear_ry
4 | -7.634723 | 0.005869 | 32 | 1071 | rx_ry_rz_cx_linear_L1 | hea_mask_L1_rx_ry_rz_cx_linear_ry
5 | -7.634185 | 0.006408 | 56 | 2124 | ry_rz_cz_linear_L3 | hea_mask_L3_ry_rz_cz_linear_ry
6 | -7.633751 | 0.006842 | 40 | 3694 | ry_rz_cz_linear_L2 | hea_mask_L2_ry_rz_cz_linear_ry
7 | -7.633671 | 0.006922 | 32 | 2676 | rx_ry_rz_cz_linear_L1 | hea_mask_L1_rx_ry_rz_cz_linear_ry
8 | -7.633187 | 0.007405 | 101 | 4903 | rx_ry_rz_rzz_linear_L3 | hea_mask_L3_rx_ry_rz_rzz_linear_ry
9 | -7.633079 | 0.007514 | 16 | 1372 | ry_cz_linear_L1 | hea_mask_L1_ry_cz_linear_ry
10 | -7.633059 | 0.007534 | 77 | 4538 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry
11 | -7.632845 | 0.007748 | 80 | 3888 | rx_ry_rz_cz_linear_L3 | hea_mask_L3_rx_ry_rz_cz_linear_ry
12 | -7.632080 | 0.008512 | 70 | 3050 | rx_ry_rz_rzz_linear_L2 | hea_mask_L2_rx_ry_rz_rzz_linear_ry
