VQE-QAS full enumeration baseline: tfim_chain_6q_J1_h0.5
reference_energy: -5.522030
n_candidates: 27
hamiltonian_profile: ZZ=0.625, XX=0.000, singleX=0.375

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -5.509101 | 0.012928 | 30 | 1915 | ry_cz_linear_L3 | hea_mask_L3_ry_cz_linear_ry_rz
2 | -5.508443 | 0.013586 | 18 | 778 | ry_cx_linear_L1 | hea_mask_L1_ry_cx_linear_ry_rz
3 | -5.508368 | 0.013662 | 24 | 955 | ry_rz_cx_linear_L1 | hea_mask_L1_ry_rz_cx_linear_ry_rz
4 | -5.507664 | 0.014365 | 58 | 3495 | rx_ry_rz_rzz_linear_L2 | hea_mask_L2_rx_ry_rz_rzz_linear_ry_rz
5 | -5.507308 | 0.014722 | 48 | 3795 | rx_ry_rz_cz_linear_L2 | hea_mask_L2_rx_ry_rz_cz_linear_ry_rz
6 | -5.507050 | 0.014980 | 46 | 4327 | ry_rz_rzz_linear_L2 | hea_mask_L2_ry_rz_rzz_linear_ry_rz
7 | -5.506994 | 0.015036 | 45 | 3496 | ry_rzz_linear_L3 | hea_mask_L3_ry_rzz_linear_ry_rz
8 | -5.506974 | 0.015056 | 30 | 1102 | rx_ry_rz_cz_linear_L1 | hea_mask_L1_rx_ry_rz_cz_linear_ry_rz
9 | -5.506955 | 0.015074 | 81 | 4379 | rx_ry_rz_rzz_linear_L3 | hea_mask_L3_rx_ry_rz_rzz_linear_ry_rz
10 | -5.506881 | 0.015149 | 63 | 3023 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry_rz
11 | -5.506858 | 0.015172 | 66 | 10452 | rx_ry_rz_cx_linear_L3 | hea_mask_L3_rx_ry_rz_cx_linear_ry_rz
12 | -5.506470 | 0.015560 | 34 | 5077 | ry_rzz_linear_L2 | hea_mask_L2_ry_rzz_linear_ry_rz
