VQE-QAS full enumeration baseline: tfim_chain_4q_J1_h0.5
reference_energy: -3.427034
n_candidates: 27
hamiltonian_profile: ZZ=0.600, XX=0.000, singleX=0.400

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -3.424136 | 0.002898 | 20 | 4000 | ry_cx_ring_L3 | hea_mask_L3_ry_cx_ring_ry_rz
2 | -3.422404 | 0.004630 | 44 | 7208 | rx_ry_rz_cx_ring_L3 | hea_mask_L3_rx_ry_rz_cx_ring_ry_rz
3 | -3.417165 | 0.009870 | 32 | 6400 | ry_rz_cx_ring_L3 | hea_mask_L3_ry_rz_cx_ring_ry_rz
4 | -3.382729 | 0.044306 | 56 | 5751 | rx_ry_rz_rzz_ring_L3 | hea_mask_L3_rx_ry_rz_rzz_ring_ry_rz
5 | -3.382502 | 0.044532 | 40 | 1029 | rx_ry_rz_rzz_ring_L2 | hea_mask_L2_rx_ry_rz_rzz_ring_ry_rz
6 | -3.382476 | 0.044558 | 32 | 1160 | ry_rz_rzz_ring_L2 | hea_mask_L2_ry_rz_rzz_ring_ry_rz
7 | -3.382152 | 0.044882 | 20 | 1394 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry_rz
8 | -3.381269 | 0.045765 | 24 | 1994 | ry_rzz_ring_L2 | hea_mask_L2_ry_rzz_ring_ry_rz
9 | -3.381010 | 0.046024 | 24 | 2125 | rx_ry_rz_rzz_ring_L1 | hea_mask_L1_rx_ry_rz_rzz_ring_ry_rz
10 | -3.380668 | 0.046366 | 44 | 2916 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry_rz
11 | -3.380661 | 0.046373 | 32 | 3186 | rx_ry_rz_cz_ring_L2 | hea_mask_L2_rx_ry_rz_cz_ring_ry_rz
12 | -3.380516 | 0.046518 | 32 | 2485 | ry_rzz_ring_L3 | hea_mask_L3_ry_rzz_ring_ry_rz
