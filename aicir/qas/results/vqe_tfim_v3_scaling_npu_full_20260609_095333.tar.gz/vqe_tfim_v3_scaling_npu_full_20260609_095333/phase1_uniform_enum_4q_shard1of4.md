VQE-QAS full enumeration baseline: tfim_chain_4q_J1_h0.5
reference_energy: -3.427034
n_candidates: 27
hamiltonian_profile: ZZ=0.600, XX=0.000, singleX=0.400

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -3.422813 | 0.004221 | 16 | 3200 | ry_cx_ring_L3 | hea_mask_L3_ry_cx_ring_ry
2 | -3.384246 | 0.042788 | 52 | 2552 | rx_ry_rz_rzz_ring_L3 | hea_mask_L3_rx_ry_rz_rzz_ring_ry
3 | -3.383506 | 0.043529 | 16 | 384 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry
4 | -3.380727 | 0.046307 | 40 | 2935 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry
5 | -3.379897 | 0.047137 | 20 | 2504 | ry_rz_cz_ring_L2 | hea_mask_L2_ry_rz_cz_ring_ry
6 | -3.377571 | 0.049463 | 36 | 888 | rx_ry_rz_rzz_ring_L2 | hea_mask_L2_rx_ry_rz_rzz_ring_ry
7 | -3.377200 | 0.049834 | 28 | 1925 | rx_ry_rz_cx_ring_L2 | hea_mask_L2_rx_ry_rz_cx_ring_ry
8 | -3.376916 | 0.050118 | 28 | 658 | ry_rz_cz_ring_L3 | hea_mask_L3_ry_rz_cz_ring_ry
9 | -3.376683 | 0.050351 | 28 | 2953 | ry_rzz_ring_L3 | hea_mask_L3_ry_rzz_ring_ry
10 | -3.376223 | 0.050811 | 12 | 611 | ry_cz_ring_L2 | hea_mask_L2_ry_cz_ring_ry
11 | -3.375078 | 0.051956 | 12 | 307 | ry_rz_cz_ring_L1 | hea_mask_L1_ry_rz_cz_ring_ry
12 | -3.374959 | 0.052075 | 8 | 169 | ry_cx_ring_L1 | hea_mask_L1_ry_cx_ring_ry
