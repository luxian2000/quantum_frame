VQE-QAS full enumeration baseline: tfim_chain_6q_J1_h0.5
reference_energy: -5.522030
n_candidates: 27
hamiltonian_profile: ZZ=0.625, XX=0.000, singleX=0.375

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -5.508846 | 0.013184 | 30 | 1583 | ry_cx_ring_L3 | hea_mask_L3_ry_cx_ring_ry_rz
2 | -5.508171 | 0.013859 | 60 | 2972 | rx_ry_rz_rzz_ring_L2 | hea_mask_L2_rx_ry_rz_rzz_ring_ry_rz
3 | -5.507614 | 0.014416 | 24 | 1467 | ry_cz_ring_L2 | hea_mask_L2_ry_cz_ring_ry_rz
4 | -5.507609 | 0.014421 | 30 | 1685 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry_rz
5 | -5.506503 | 0.015526 | 36 | 6344 | rx_ry_rz_rzz_ring_L1 | hea_mask_L1_rx_ry_rz_rzz_ring_ry_rz
6 | -5.506230 | 0.015800 | 66 | 5221 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry_rz
7 | -5.506081 | 0.015949 | 48 | 3951 | ry_rz_rzz_ring_L2 | hea_mask_L2_ry_rz_rzz_ring_ry_rz
8 | -5.505751 | 0.016279 | 48 | 3566 | ry_rz_cz_ring_L3 | hea_mask_L3_ry_rz_cz_ring_ry_rz
9 | -5.505730 | 0.016300 | 48 | 3942 | ry_rzz_ring_L3 | hea_mask_L3_ry_rzz_ring_ry_rz
10 | -5.505689 | 0.016341 | 36 | 3341 | ry_rzz_ring_L2 | hea_mask_L2_ry_rzz_ring_ry_rz
11 | -5.504806 | 0.017224 | 30 | 3177 | ry_rz_rzz_ring_L1 | hea_mask_L1_ry_rz_rzz_ring_ry_rz
12 | -5.501833 | 0.020196 | 18 | 681 | ry_cx_ring_L1 | hea_mask_L1_ry_cx_ring_ry_rz
