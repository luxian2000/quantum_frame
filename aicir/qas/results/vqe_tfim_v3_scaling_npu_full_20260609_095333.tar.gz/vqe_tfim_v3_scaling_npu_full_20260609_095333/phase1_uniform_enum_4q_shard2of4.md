VQE-QAS full enumeration baseline: tfim_chain_4q_J1_h0.5
reference_energy: -3.427034
n_candidates: 27
hamiltonian_profile: ZZ=0.600, XX=0.000, singleX=0.400

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -3.408481 | 0.018553 | 44 | 8800 | rx_ry_rz_cz_linear_L3 | hea_mask_L3_rx_ry_rz_cz_linear_ry_rz
2 | -3.385622 | 0.041413 | 20 | 1244 | ry_cz_linear_L3 | hea_mask_L3_ry_cz_linear_ry_rz
3 | -3.384617 | 0.042417 | 20 | 850 | ry_cx_linear_L3 | hea_mask_L3_ry_cx_linear_ry_rz
4 | -3.382974 | 0.044060 | 32 | 3108 | ry_rz_cx_linear_L3 | hea_mask_L3_ry_rz_cx_linear_ry_rz
5 | -3.382578 | 0.044456 | 32 | 2189 | rx_ry_rz_cx_linear_L2 | hea_mask_L2_rx_ry_rz_cx_linear_ry_rz
6 | -3.382295 | 0.044739 | 53 | 2725 | rx_ry_rz_rzz_linear_L3 | hea_mask_L3_rx_ry_rz_rzz_linear_ry_rz
7 | -3.382109 | 0.044925 | 44 | 2884 | rx_ry_rz_cx_linear_L3 | hea_mask_L3_rx_ry_rz_cx_linear_ry_rz
8 | -3.381677 | 0.045357 | 23 | 1339 | rx_ry_rz_rzz_linear_L1 | hea_mask_L1_rx_ry_rz_rzz_linear_ry_rz
9 | -3.381584 | 0.045450 | 41 | 1308 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry_rz
10 | -3.381476 | 0.045558 | 16 | 735 | ry_cz_linear_L2 | hea_mask_L2_ry_cz_linear_ry_rz
11 | -3.381426 | 0.045608 | 30 | 3458 | ry_rz_rzz_linear_L2 | hea_mask_L2_ry_rz_rzz_linear_ry_rz
12 | -3.381265 | 0.045769 | 22 | 2419 | ry_rzz_linear_L2 | hea_mask_L2_ry_rzz_linear_ry_rz
