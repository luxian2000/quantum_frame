VQE-QAS full enumeration baseline: tfim_chain_6q_J1_h0.5
reference_energy: -5.522030
n_candidates: 27
hamiltonian_profile: ZZ=0.625, XX=0.000, singleX=0.375

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -5.519092 | 0.002938 | 24 | 1834 | ry_cx_linear_L3 | hea_mask_L3_ry_cx_linear_ry
2 | -5.508378 | 0.013652 | 24 | 558 | rx_ry_rz_cx_linear_L1 | hea_mask_L1_rx_ry_rz_cx_linear_ry
3 | -5.506900 | 0.015129 | 42 | 2395 | ry_rz_cz_linear_L3 | hea_mask_L3_ry_rz_cz_linear_ry
4 | -5.506737 | 0.015292 | 60 | 3725 | rx_ry_rz_cx_linear_L3 | hea_mask_L3_rx_ry_rz_cx_linear_ry
5 | -5.506618 | 0.015412 | 30 | 1235 | ry_rz_cz_linear_L2 | hea_mask_L2_ry_rz_cz_linear_ry
6 | -5.506201 | 0.015828 | 18 | 723 | ry_rz_cx_linear_L1 | hea_mask_L1_ry_rz_cx_linear_ry
7 | -5.505939 | 0.016091 | 57 | 3146 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry
8 | -5.505846 | 0.016184 | 24 | 792 | ry_cz_linear_L3 | hea_mask_L3_ry_cz_linear_ry
9 | -5.504344 | 0.017685 | 18 | 2969 | ry_rz_cz_linear_L1 | hea_mask_L1_ry_rz_cz_linear_ry
10 | -5.502372 | 0.019658 | 60 | 2083 | rx_ry_rz_cz_linear_L3 | hea_mask_L3_rx_ry_rz_cz_linear_ry
11 | -5.502320 | 0.019709 | 75 | 3766 | rx_ry_rz_rzz_linear_L3 | hea_mask_L3_rx_ry_rz_rzz_linear_ry
12 | -5.501795 | 0.020235 | 42 | 1319 | rx_ry_rz_cz_linear_L2 | hea_mask_L2_rx_ry_rz_cz_linear_ry
