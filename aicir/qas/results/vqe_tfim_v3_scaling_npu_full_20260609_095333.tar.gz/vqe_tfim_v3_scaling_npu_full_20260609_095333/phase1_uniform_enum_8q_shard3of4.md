VQE-QAS full enumeration baseline: tfim_chain_8q_J1_h0.5
reference_energy: -7.640593
n_candidates: 27
hamiltonian_profile: ZZ=0.636, XX=0.000, singleX=0.364

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -7.635278 | 0.005315 | 32 | 2062 | ry_cz_ring_L2 | hea_mask_L2_ry_cz_ring_ry_rz
2 | -7.634803 | 0.005790 | 40 | 3624 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry_rz
3 | -7.632887 | 0.007705 | 112 | 6692 | rx_ry_rz_rzz_ring_L3 | hea_mask_L3_rx_ry_rz_rzz_ring_ry_rz
4 | -7.632418 | 0.008175 | 64 | 5215 | ry_rz_cz_ring_L3 | hea_mask_L3_ry_rz_cz_ring_ry_rz
5 | -7.632112 | 0.008481 | 48 | 2866 | ry_rzz_ring_L2 | hea_mask_L2_ry_rzz_ring_ry_rz
6 | -7.632094 | 0.008499 | 80 | 5735 | rx_ry_rz_rzz_ring_L2 | hea_mask_L2_rx_ry_rz_rzz_ring_ry_rz
7 | -7.631672 | 0.008921 | 64 | 3325 | ry_rz_rzz_ring_L2 | hea_mask_L2_ry_rz_rzz_ring_ry_rz
8 | -7.631312 | 0.009281 | 48 | 1929 | rx_ry_rz_rzz_ring_L1 | hea_mask_L1_rx_ry_rz_rzz_ring_ry_rz
9 | -7.630961 | 0.009632 | 24 | 1840 | ry_cz_ring_L1 | hea_mask_L1_ry_cz_ring_ry_rz
10 | -7.630485 | 0.010107 | 88 | 5173 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry_rz
11 | -7.630279 | 0.010313 | 64 | 5909 | ry_rzz_ring_L3 | hea_mask_L3_ry_rzz_ring_ry_rz
12 | -7.629200 | 0.011393 | 88 | 5060 | rx_ry_rz_cz_ring_L3 | hea_mask_L3_rx_ry_rz_cz_ring_ry_rz
