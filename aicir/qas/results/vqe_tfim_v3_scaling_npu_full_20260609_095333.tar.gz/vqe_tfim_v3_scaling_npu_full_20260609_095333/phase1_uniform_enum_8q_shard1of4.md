VQE-QAS full enumeration baseline: tfim_chain_8q_J1_h0.5
reference_energy: -7.640593
n_candidates: 27
hamiltonian_profile: ZZ=0.636, XX=0.000, singleX=0.364

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -7.633819 | 0.006773 | 56 | 1889 | rx_ry_rz_cz_ring_L2 | hea_mask_L2_rx_ry_rz_cz_ring_ry
2 | -7.632960 | 0.007633 | 32 | 1675 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry
3 | -7.631851 | 0.008742 | 56 | 1875 | ry_rz_cz_ring_L3 | hea_mask_L3_ry_rz_cz_ring_ry
4 | -7.631580 | 0.009012 | 80 | 6703 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry
5 | -7.630066 | 0.010526 | 24 | 855 | ry_cz_ring_L2 | hea_mask_L2_ry_cz_ring_ry
6 | -7.629101 | 0.011491 | 104 | 5020 | rx_ry_rz_rzz_ring_L3 | hea_mask_L3_rx_ry_rz_rzz_ring_ry
7 | -7.628811 | 0.011782 | 16 | 571 | ry_cx_ring_L1 | hea_mask_L1_ry_cx_ring_ry
8 | -7.628619 | 0.011973 | 56 | 2780 | ry_rzz_ring_L3 | hea_mask_L3_ry_rzz_ring_ry
9 | -7.628366 | 0.012227 | 56 | 3170 | ry_rz_cx_ring_L3 | hea_mask_L3_ry_rz_cx_ring_ry
10 | -7.627817 | 0.012776 | 80 | 2535 | rx_ry_rz_cz_ring_L3 | hea_mask_L3_rx_ry_rz_cz_ring_ry
11 | -7.627624 | 0.012969 | 24 | 1569 | ry_rzz_ring_L1 | hea_mask_L1_ry_rzz_ring_ry
12 | -7.627410 | 0.013182 | 40 | 2126 | ry_rzz_ring_L2 | hea_mask_L2_ry_rzz_ring_ry
