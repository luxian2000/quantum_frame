VQE-QAS full enumeration baseline: tfim_chain_4q_J1_h0.5
reference_energy: -3.427034
n_candidates: 27
hamiltonian_profile: ZZ=0.600, XX=0.000, singleX=0.400

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -3.426542 | 0.000492 | 16 | 2410 | ry_cx_linear_L3 | hea_mask_L3_ry_cx_linear_ry
2 | -3.424412 | 0.002623 | 12 | 2023 | ry_cx_linear_L2 | hea_mask_L2_ry_cx_linear_ry
3 | -3.424309 | 0.002725 | 40 | 4654 | rx_ry_rz_cx_linear_L3 | hea_mask_L3_rx_ry_rz_cx_linear_ry
4 | -3.390504 | 0.036530 | 16 | 636 | ry_cz_linear_L3 | hea_mask_L3_ry_cz_linear_ry
5 | -3.390466 | 0.036568 | 40 | 2602 | rx_ry_rz_cz_linear_L3 | hea_mask_L3_rx_ry_rz_cz_linear_ry
6 | -3.389349 | 0.037685 | 12 | 2400 | ry_cz_linear_L2 | hea_mask_L2_ry_cz_linear_ry
7 | -3.384288 | 0.042746 | 28 | 5432 | ry_rz_cz_linear_L3 | hea_mask_L3_ry_rz_cz_linear_ry
8 | -3.381829 | 0.045205 | 8 | 355 | ry_cx_linear_L1 | hea_mask_L1_ry_cx_linear_ry
9 | -3.381819 | 0.045215 | 16 | 1069 | rx_ry_rz_cx_linear_L1 | hea_mask_L1_rx_ry_rz_cx_linear_ry
10 | -3.381682 | 0.045352 | 37 | 1284 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry
11 | -3.381646 | 0.045388 | 20 | 2665 | ry_rz_cx_linear_L2 | hea_mask_L2_ry_rz_cx_linear_ry
12 | -3.380644 | 0.046390 | 28 | 3028 | rx_ry_rz_cx_linear_L2 | hea_mask_L2_rx_ry_rz_cx_linear_ry
