VQE-QAS full enumeration baseline: tfim_chain_8q_J1_h0.5
reference_energy: -7.640593
n_candidates: 27
hamiltonian_profile: ZZ=0.636, XX=0.000, singleX=0.364

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -7.635028 | 0.005565 | 40 | 2764 | ry_cx_linear_L3 | hea_mask_L3_ry_cx_linear_ry_rz
2 | -7.634868 | 0.005725 | 32 | 1480 | ry_cz_linear_L2 | hea_mask_L2_ry_cz_linear_ry_rz
3 | -7.634539 | 0.006054 | 64 | 2352 | rx_ry_rz_cz_linear_L2 | hea_mask_L2_rx_ry_rz_cz_linear_ry_rz
4 | -7.634372 | 0.006221 | 85 | 5249 | ry_rz_rzz_linear_L3 | hea_mask_L3_ry_rz_rzz_linear_ry_rz
5 | -7.634096 | 0.006496 | 40 | 2610 | ry_cz_linear_L3 | hea_mask_L3_ry_cz_linear_ry_rz
6 | -7.634022 | 0.006571 | 109 | 6303 | rx_ry_rz_rzz_linear_L3 | hea_mask_L3_rx_ry_rz_rzz_linear_ry_rz
7 | -7.633501 | 0.007092 | 61 | 4908 | ry_rzz_linear_L3 | hea_mask_L3_ry_rzz_linear_ry_rz
8 | -7.633019 | 0.007574 | 64 | 2860 | ry_rz_cz_linear_L3 | hea_mask_L3_ry_rz_cz_linear_ry_rz
9 | -7.632799 | 0.007794 | 64 | 4801 | ry_rz_cx_linear_L3 | hea_mask_L3_ry_rz_cx_linear_ry_rz
10 | -7.632458 | 0.008134 | 78 | 4555 | rx_ry_rz_rzz_linear_L2 | hea_mask_L2_rx_ry_rz_rzz_linear_ry_rz
11 | -7.632320 | 0.008272 | 48 | 1828 | ry_rz_cz_linear_L2 | hea_mask_L2_ry_rz_cz_linear_ry_rz
12 | -7.632157 | 0.008435 | 88 | 7000 | rx_ry_rz_cz_linear_L3 | hea_mask_L3_rx_ry_rz_cz_linear_ry_rz
