VQE-QAS full enumeration baseline: tfim_chain_6q_J1_h0.5
reference_energy: -5.522030
n_candidates: 27
hamiltonian_profile: ZZ=0.625, XX=0.000, singleX=0.375

Top fair VQE candidates
rank | fair | delta_ref | n_params | evals | family | name
1 | -5.507644 | 0.014386 | 42 | 1312 | rx_ry_rz_cz_ring_L2 | hea_mask_L2_rx_ry_rz_cz_ring_ry
2 | -5.506897 | 0.015133 | 24 | 559 | rx_ry_rz_cz_ring_L1 | hea_mask_L1_rx_ry_rz_cz_ring_ry
3 | -5.506536 | 0.015493 | 24 | 1084 | ry_cz_ring_L3 | hea_mask_L3_ry_cz_ring_ry
4 | -5.505291 | 0.016738 | 60 | 3537 | ry_rz_rzz_ring_L3 | hea_mask_L3_ry_rz_rzz_ring_ry
5 | -5.504747 | 0.017282 | 30 | 1109 | ry_rz_cx_ring_L2 | hea_mask_L2_ry_rz_cx_ring_ry
6 | -5.504054 | 0.017976 | 30 | 1637 | ry_rz_cz_ring_L2 | hea_mask_L2_ry_rz_cz_ring_ry
7 | -5.503196 | 0.018834 | 42 | 2624 | rx_ry_rz_cx_ring_L2 | hea_mask_L2_rx_ry_rz_cx_ring_ry
8 | -5.502872 | 0.019158 | 60 | 2642 | rx_ry_rz_cz_ring_L3 | hea_mask_L3_rx_ry_rz_cz_ring_ry
9 | -5.501862 | 0.020168 | 12 | 324 | ry_cx_ring_L1 | hea_mask_L1_ry_cx_ring_ry
10 | -5.501860 | 0.020169 | 18 | 559 | ry_rz_cx_ring_L1 | hea_mask_L1_ry_rz_cx_ring_ry
11 | -5.501811 | 0.020219 | 18 | 820 | ry_cz_ring_L2 | hea_mask_L2_ry_cz_ring_ry
12 | -5.500669 | 0.021361 | 42 | 2103 | ry_rz_cx_ring_L3 | hea_mask_L3_ry_rz_cx_ring_ry
