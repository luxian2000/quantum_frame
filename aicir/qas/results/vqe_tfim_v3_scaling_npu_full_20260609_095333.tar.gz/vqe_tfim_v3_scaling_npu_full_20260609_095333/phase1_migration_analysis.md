VQE-QAS v3 Phase 1 migration analysis
input_dir: outputs/vqe_tfim_v3_scaling_npu_full
pair | family_spearman | topK_family_overlap | top5 | top10 | top20 | allows_weak_extrapolation
4->6 | 0.2289 | 0.3333 | 0.5000 | 0.3750 | 0.4667 | False
6->8 | 0.4616 | 0.5000 | 0.3333 | 0.4286 | 0.8000 | False
