TFIM reference alignment
tolerance: 1.0e-09 | passed: True
n_qubits | J | h | boundary | dense | free_fermion | abs_diff
4 | 1 | 0.5 | OBC | -3.427034088908 | -3.427034088908 | 1.332e-15
6 | 1 | 0.5 | OBC | -5.522029570800 | -5.522029570800 | 7.994e-15
8 | 1 | 0.5 | OBC | -7.640592553590 | -7.640592553590 | 2.665e-15
